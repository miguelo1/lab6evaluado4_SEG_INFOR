from prime_gentest import*
import random

#2lineasxd

q=random.choice(listaprimos)#se simula que el server haga su decision de n primo independientemente
# gen_aleatorio=random.randrange(1,(q-1),1)




    
print("El primo seleccionado(Q) por el servidor es:",q)

  